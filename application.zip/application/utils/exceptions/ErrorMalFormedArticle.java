/**
 * 
 */
package application.utils.exceptions;

/**
 * @author agonzalez
 *
 */
@SuppressWarnings("serial")
public class ErrorMalFormedArticle extends Exception {

	/**
	 * 
	 */
	public ErrorMalFormedArticle() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message error message
	 */
	public ErrorMalFormedArticle(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
